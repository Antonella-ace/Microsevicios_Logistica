package com.logistica.usuario_service.controller;

import com.logistica.usuario_service.model.Usuario;
import com.logistica.usuario_service.service.UsuarioService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    private final UsuarioService service;

    public UsuarioController(UsuarioService service) {
        this.service = service;
    }

    @GetMapping
    public List<Usuario> listar() {
        return service.listar();
    }

    @PostMapping
    public Usuario guardar(@RequestBody Usuario usuario) {
        return service.guardar(usuario);
    }

    @GetMapping("/buscar/{correo}")
    public Usuario buscar(@PathVariable String correo){
        return service.login(correo);
    }


}