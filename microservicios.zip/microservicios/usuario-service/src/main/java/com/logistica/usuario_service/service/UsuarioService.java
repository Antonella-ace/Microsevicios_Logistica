package com.logistica.usuario_service.service;

import com.logistica.usuario_service.model.Usuario;
import com.logistica.usuario_service.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

    private final UsuarioRepository repository;

    public UsuarioService(UsuarioRepository repository) {
        this.repository = repository;
    }

    public List<Usuario> listar() {
        return repository.findAll();
    }

    public Usuario guardar(Usuario usuario) {
        return repository.save(usuario);
    }

    public Usuario login(String correo){
        return repository.findByCorreo(correo).orElse(null);
    }
}