package com.logistica.inventario_service.service;

import com.logistica.inventario_service.model.Inventario;
import com.logistica.inventario_service.repository.InventarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class InventarioService {

    private final InventarioRepository repository;

    public List<Inventario> listar() {
        return repository.findAll();
    }

    public Inventario guardar(Inventario inventario) {
        return repository.save(inventario);
    }

    public Inventario entrada(Long id, Integer cantidad) {

        Inventario inv = repository.findById(id).orElse(null);

        if(inv != null){
            inv.setStockActual(inv.getStockActual() + cantidad);
            return repository.save(inv);
        }

        return null;
    }

    public Inventario salida(Long id, Integer cantidad) {

        Inventario inv = repository.findById(id).orElse(null);

        if(inv != null && inv.getStockActual() >= cantidad){
            inv.setStockActual(inv.getStockActual() - cantidad);
            return repository.save(inv);
        }

        return null;
    }
}