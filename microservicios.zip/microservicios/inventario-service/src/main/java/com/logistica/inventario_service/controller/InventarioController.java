package com.logistica.inventario_service.controller;

import com.logistica.inventario_service.model.Inventario;
import com.logistica.inventario_service.service.InventarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventario")
@RequiredArgsConstructor
public class InventarioController {

    private final InventarioService service;

    @GetMapping
    public List<Inventario> listar(){
        return service.listar();
    }

    @PostMapping
    public Inventario guardar(@RequestBody Inventario inventario){
        return service.guardar(inventario);
    }

    @PatchMapping("/{id}/entrada/{cantidad}")
    public Inventario entrada(
            @PathVariable Long id,
            @PathVariable Integer cantidad){
        return service.entrada(id,cantidad);
    }

    @PatchMapping("/{id}/salida/{cantidad}")
    public Inventario salida(
            @PathVariable Long id,
            @PathVariable Integer cantidad){
        return service.salida(id,cantidad);
    }
}