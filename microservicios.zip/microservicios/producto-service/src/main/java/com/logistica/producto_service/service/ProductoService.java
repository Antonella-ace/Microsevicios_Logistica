package com.logistica.producto_service.service;

import com.logistica.producto_service.model.Producto;
import com.logistica.producto_service.repository.ProductoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductoService {

    private final ProductoRepository repository;

    public List<Producto> listar() {
        return repository.findAll();
    }

    public Producto guardar(Producto producto) {
        return repository.save(producto);
    }

    public Producto buscar(Long id) {
        return repository.findById(id).orElse(null);
    }

    public Producto actualizar(Long id, Producto nuevoProducto) {

        Producto producto = repository.findById(id).orElse(null);

        if (producto != null) {
            producto.setNombre(nuevoProducto.getNombre());
            producto.setCategoria(nuevoProducto.getCategoria());
            producto.setPrecio(nuevoProducto.getPrecio());
            producto.setStock(nuevoProducto.getStock());
            producto.setDescripcion(nuevoProducto.getDescripcion());
            producto.setActivo(nuevoProducto.getActivo());

            return repository.save(producto);
        }

        return null;
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}