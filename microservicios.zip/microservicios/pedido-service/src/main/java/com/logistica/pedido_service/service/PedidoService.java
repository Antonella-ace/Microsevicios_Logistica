package com.logistica.pedido_service.service;

import com.logistica.pedido_service.model.Pedido;
import com.logistica.pedido_service.repository.PedidoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PedidoService {

    private final PedidoRepository repository;
    private final RestTemplate restTemplate;

    public List<Pedido> listar() {
        return repository.findAll();
    }

    public Pedido guardar(Pedido pedido) {

        // Descontar stock en inventario
        restTemplate.patchForObject(
                "http://localhost:8083/api/inventario/1/salida/" + pedido.getCantidad(),
                null,
                Object.class
        );

        // Crear envío automático
        String envioJson =
                """
                {
                  "destino":"%s",
                  "peso":2,
                  "tipo":"NORMAL"
                }
                """.formatted(pedido.getDireccion());

        restTemplate.postForObject(
                "http://localhost:8086/api/envios",
                envioJson,
                Object.class
        );

        // Guardar pedido
        pedido.setFecha(LocalDateTime.now());
        pedido.setEstado("ENVIADO");

        return repository.save(pedido);
    }
}