package com.logistica.pago_service.service;

import com.logistica.pago_service.model.Pago;
import com.logistica.pago_service.repository.PagoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class PagoServiceTest {

    @Mock
    private PagoRepository repository;

    @InjectMocks
    private PagoService service;

    @Test
    void deberiaRetornarListaPagos() {

        Pago pago = new Pago();
        pago.setId(1L);
        pago.setMonto(5000.0);

        Mockito.when(repository.findAll())
                .thenReturn(List.of(pago));

        List<Pago> resultado = service.listar();

        assertEquals(1, resultado.size());

        verify(repository).findAll();
    }

    @Test
    void deberiaBuscarPagoPorId() {

        Pago pago = new Pago();
        pago.setId(1L);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(pago));

        Pago resultado = service.buscar(1L);

        assertEquals(1L, resultado.getId());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaGuardarPagoConEstadoPendiente() {

        Pago pago = new Pago();
        pago.setPedidoId(1L);
        pago.setMonto(10000.0);
        pago.setMetodoPago("Tarjeta");

        Mockito.when(repository.save(Mockito.any(Pago.class)))
                .thenAnswer(i -> i.getArgument(0));

        Pago resultado = service.guardar(pago);

        assertEquals("PENDIENTE", resultado.getEstado());

        verify(repository).save(pago);
    }

    @Test
    void deberiaMarcarPagoComoPagado() {

        Pago pago = new Pago();
        pago.setId(1L);
        pago.setEstado("PENDIENTE");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(pago));

        Mockito.when(repository.save(Mockito.any(Pago.class)))
                .thenAnswer(i -> i.getArgument(0));

        Pago resultado = service.pagar(1L);

        assertEquals("PAGADO", resultado.getEstado());

        verify(repository).save(pago);
    }

    @Test
    void deberiaEliminarPago() {

        Pago pago = new Pago();
        pago.setId(1L);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(pago));

        service.eliminar(1L);

        verify(repository).delete(pago);
    }
}