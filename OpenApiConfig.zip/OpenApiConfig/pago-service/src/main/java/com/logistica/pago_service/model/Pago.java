package com.logistica.pago_service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name = "pagos")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa un pago asociado a un pedido")
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único del pago", example = "1")
    private Long id;

    @NotNull(message = "El pedidoId es obligatorio")
    @Schema(description = "ID del pedido asociado", example = "100")
    private Long pedidoId;

    @NotNull(message = "El monto es obligatorio")
    @Positive(message = "El monto debe ser mayor a 0")
    @Schema(description = "Monto del pago", example = "59990")
    private Double monto;

    @NotBlank(message = "El método de pago es obligatorio")
    @Schema(description = "Método de pago utilizado", example = "TARJETA")
    private String metodoPago;

    @Schema(description = "Estado actual del pago", example = "PENDIENTE")
    private String estado = "PENDIENTE";
}