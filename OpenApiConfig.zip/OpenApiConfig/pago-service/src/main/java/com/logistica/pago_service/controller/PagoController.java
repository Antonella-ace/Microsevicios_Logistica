package com.logistica.pago_service.controller;

import com.logistica.pago_service.model.Pago;
import com.logistica.pago_service.service.PagoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pagos")
@RequiredArgsConstructor
public class PagoController {

    private final PagoService service;

    @Operation(
            summary = "Listar pagos",
            description = "Obtiene todos los pagos registrados"
    )
    @ApiResponse(responseCode = "200", description = "Listado obtenido correctamente")
    @GetMapping
    public List<Pago> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Buscar pago",
            description = "Busca un pago por ID"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Pago encontrado"),
            @ApiResponse(responseCode = "404", description = "Pago no encontrado")
    })
    @GetMapping("/{id}")
    public Pago buscar(@PathVariable Long id) {
        return service.buscar(id);
    }

    @Operation(
            summary = "Crear pago",
            description = "Registra un nuevo pago"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Pago creado"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public Pago guardar(@Valid @RequestBody Pago pago) {
        return service.guardar(pago);
    }

    @Operation(
            summary = "Actualizar pago",
            description = "Actualiza un pago existente"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Pago actualizado"),
            @ApiResponse(responseCode = "404", description = "Pago no encontrado")
    })
    @PutMapping("/{id}")
    public Pago actualizar(@PathVariable Long id,
                           @Valid @RequestBody Pago pago) {
        return service.actualizar(id, pago);
    }

    @Operation(
            summary = "Marcar pago como pagado",
            description = "Cambia el estado del pago a PAGADO"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Pago procesado correctamente"),
            @ApiResponse(responseCode = "404", description = "Pago no encontrado")
    })
    @PatchMapping("/{id}/pagar")
    public Pago pagar(@PathVariable Long id) {
        return service.pagar(id);
    }

    @Operation(
            summary = "Eliminar pago",
            description = "Elimina un pago por ID"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Pago eliminado"),
            @ApiResponse(responseCode = "404", description = "Pago no encontrado")
    })
    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}