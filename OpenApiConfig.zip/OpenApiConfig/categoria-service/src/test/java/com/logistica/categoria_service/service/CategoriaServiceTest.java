package com.logistica.categoria_service.service;

import com.logistica.categoria_service.model.Categoria;
import com.logistica.categoria_service.repository.CategoriaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CategoriaServiceTest {

    @Mock
    private CategoriaRepository repository;

    @InjectMocks
    private CategoriaService service;

    @Test
    void deberiaListarCategorias() {

        Categoria categoria = new Categoria();
        categoria.setId(1L);
        categoria.setNombre("Electrónica");

        Mockito.when(repository.findAll())
                .thenReturn(List.of(categoria));

        List<Categoria> resultado = service.listar();

        assertEquals(1, resultado.size());
        assertEquals("Electrónica", resultado.get(0).getNombre());

        verify(repository).findAll();
    }

    @Test
    void deberiaGuardarCategoria() {

        Categoria categoria = new Categoria();
        categoria.setNombre("Ropa");
        categoria.setDescripcion("Vestuario");

        Mockito.when(repository.save(categoria))
                .thenReturn(categoria);

        Categoria resultado = service.guardar(categoria);

        assertEquals("Ropa", resultado.getNombre());

        verify(repository).save(categoria);
    }

    @Test
    void deberiaBuscarCategoriaPorId() {

        Categoria categoria = new Categoria();
        categoria.setId(1L);
        categoria.setNombre("Tecnología");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(categoria));

        Categoria resultado = service.buscar(1L);

        assertEquals("Tecnología", resultado.getNombre());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaActualizarCategoria() {

        Categoria existente = new Categoria();
        existente.setId(1L);
        existente.setNombre("Antigua");
        existente.setDescripcion("Desc antigua");

        Categoria nueva = new Categoria();
        nueva.setNombre("Nueva");
        nueva.setDescripcion("Desc nueva");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(existente));

        Mockito.when(repository.save(existente))
                .thenReturn(existente);

        Categoria resultado = service.actualizar(1L, nueva);

        assertEquals("Nueva", resultado.getNombre());
        assertEquals("Desc nueva", resultado.getDescripcion());

        verify(repository).save(existente);
    }

    @Test
    void deberiaEliminarCategoria() {

        service.eliminar(1L);

        verify(repository).deleteById(1L);
    }
}