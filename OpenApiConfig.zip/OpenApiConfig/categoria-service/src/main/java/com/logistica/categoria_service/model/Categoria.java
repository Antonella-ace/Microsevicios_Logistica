package com.logistica.categoria_service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "categorias")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa una categoría de productos")
public class Categoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único de la categoría", example = "1")
    private Long id;

    @NotBlank(message = "Nombre obligatorio")
    @Schema(description = "Nombre de la categoría", example = "Electrónica")
    private String nombre;

    @NotBlank(message = "Descripcion obligatoria")
    @Schema(description = "Descripción de la categoría", example = "Productos electrónicos y tecnológicos")
    private String descripcion;
}