package com.logistica.categoria_service.controller;

import com.logistica.categoria_service.model.Categoria;
import com.logistica.categoria_service.service.CategoriaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categorias")
public class CategoriaController {

    private final CategoriaService service;

    public CategoriaController(CategoriaService service) {
        this.service = service;
    }

    @Operation(
            summary = "Listar categorías",
            description = "Obtiene todas las categorías registradas"
    )
    @ApiResponse(responseCode = "200", description = "Listado obtenido correctamente")
    @GetMapping
    public List<Categoria> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Buscar categoría",
            description = "Busca una categoría por ID"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Categoría encontrada"),
            @ApiResponse(responseCode = "404", description = "Categoría no encontrada")
    })
    @GetMapping("/{id}")
    public Categoria buscar(@PathVariable Long id) {
        return service.buscar(id);
    }

    @Operation(
            summary = "Crear categoría",
            description = "Registra una nueva categoría"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Categoría creada"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public Categoria guardar(@Valid @RequestBody Categoria categoria) {
        return service.guardar(categoria);
    }

    @Operation(
            summary = "Actualizar categoría",
            description = "Actualiza una categoría existente"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Categoría actualizada"),
            @ApiResponse(responseCode = "404", description = "Categoría no encontrada")
    })
    @PutMapping("/{id}")
    public Categoria actualizar(@PathVariable Long id,
                                @Valid @RequestBody Categoria categoria) {
        return service.actualizar(id, categoria);
    }

    @Operation(
            summary = "Eliminar categoría",
            description = "Elimina una categoría por ID"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Categoría eliminada"),
            @ApiResponse(responseCode = "404", description = "Categoría no encontrada")
    })
    @DeleteMapping("/{id}")
    public String eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return "Categoria eliminada";
    }
}