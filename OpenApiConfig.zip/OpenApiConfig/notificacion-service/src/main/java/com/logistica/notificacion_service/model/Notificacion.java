package com.logistica.notificacion_service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name="notificaciones")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa una notificación enviada a un destinatario")
public class Notificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único de la notificación", example = "1")
    private Long id;

    @NotBlank(message = "Mensaje obligatorio")
    @Schema(description = "Contenido de la notificación", example = "Su pedido ha sido enviado")
    private String mensaje;

    @NotBlank(message = "Destinatario obligatorio")
    @Schema(description = "Correo o destinatario de la notificación", example = "cliente@gmail.com")
    private String destinatario;

    @Schema(description = "Estado actual de la notificación", example = "PENDIENTE")
    private String estado = "PENDIENTE";
}