package com.logistica.notificacion_service.controller;

import com.logistica.notificacion_service.model.Notificacion;
import com.logistica.notificacion_service.service.NotificacionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notificaciones")
public class NotificacionController {

    private final NotificacionService service;

    public NotificacionController(NotificacionService service) {
        this.service = service;
    }

    @Operation(
            summary = "Listar notificaciones",
            description = "Obtiene todas las notificaciones registradas"
    )
    @ApiResponse(responseCode = "200", description = "Listado obtenido correctamente")
    @GetMapping
    public List<Notificacion> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Buscar notificación",
            description = "Busca una notificación por su ID"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Notificación encontrada"),
            @ApiResponse(responseCode = "404", description = "Notificación no encontrada")
    })
    @GetMapping("/{id}")
    public Notificacion buscar(@PathVariable Long id) {
        return service.buscar(id);
    }

    @Operation(
            summary = "Crear notificación",
            description = "Registra una nueva notificación"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Notificación creada"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public Notificacion guardar(@Valid @RequestBody Notificacion n) {
        return service.guardar(n);
    }

    @Operation(
            summary = "Actualizar notificación",
            description = "Actualiza los datos de una notificación existente"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Notificación actualizada"),
            @ApiResponse(responseCode = "404", description = "Notificación no encontrada")
    })
    @PutMapping("/{id}")
    public Notificacion actualizar(@PathVariable Long id,
                                   @Valid @RequestBody Notificacion n) {
        return service.actualizar(id, n);
    }

    @Operation(
            summary = "Enviar notificación",
            description = "Cambia el estado de la notificación a ENVIADA"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Notificación enviada"),
            @ApiResponse(responseCode = "404", description = "Notificación no encontrada")
    })
    @PatchMapping("/{id}/enviar")
    public Notificacion enviar(@PathVariable Long id) {
        return service.enviar(id);
    }

    @Operation(
            summary = "Eliminar notificación",
            description = "Elimina una notificación por ID"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Notificación eliminada"),
            @ApiResponse(responseCode = "404", description = "Notificación no encontrada")
    })
    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}