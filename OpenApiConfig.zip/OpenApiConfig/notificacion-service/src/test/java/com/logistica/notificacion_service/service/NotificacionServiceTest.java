package com.logistica.notificacion_service.service;

import com.logistica.notificacion_service.model.Notificacion;
import com.logistica.notificacion_service.repository.NotificacionRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class NotificacionServiceTest {

    @Mock
    private NotificacionRepository repository;

    @InjectMocks
    private NotificacionService service;

    @Test
    void deberiaRetornarListaNotificaciones() {

        Notificacion n = new Notificacion();
        n.setId(1L);
        n.setMensaje("Pedido enviado");

        Mockito.when(repository.findAll())
                .thenReturn(List.of(n));

        List<Notificacion> resultado = service.listar();

        assertEquals(1, resultado.size());
        assertEquals("Pedido enviado", resultado.get(0).getMensaje());

        verify(repository).findAll();
    }

    @Test
    void deberiaBuscarNotificacionPorId() {

        Notificacion n = new Notificacion();
        n.setId(1L);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(n));

        Notificacion resultado = service.buscar(1L);

        assertEquals(1L, resultado.getId());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaGuardarNotificacionConEstadoPendiente() {

        Notificacion n = new Notificacion();
        n.setMensaje("Pedido creado");
        n.setDestinatario("juan@gmail.com");

        Mockito.when(repository.save(Mockito.any(Notificacion.class)))
                .thenAnswer(i -> i.getArgument(0));

        Notificacion resultado = service.guardar(n);

        assertEquals("PENDIENTE", resultado.getEstado());

        verify(repository).save(n);
    }

    @Test
    void deberiaEnviarNotificacion() {

        Notificacion n = new Notificacion();
        n.setId(1L);
        n.setEstado("PENDIENTE");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(n));

        Mockito.when(repository.save(Mockito.any(Notificacion.class)))
                .thenAnswer(i -> i.getArgument(0));

        Notificacion resultado = service.enviar(1L);

        assertEquals("ENVIADA", resultado.getEstado());

        verify(repository).save(n);
    }

    @Test
    void deberiaEliminarNotificacion() {

        Notificacion n = new Notificacion();
        n.setId(1L);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(n));

        service.eliminar(1L);

        verify(repository).delete(n);
    }
}