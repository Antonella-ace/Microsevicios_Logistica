package com.logistica.producto_service.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {

        return new OpenAPI()
                .info(
                        new Info()
                                .title("Producto Service API")
                                .version("1.0")
                                .description("Microservicio encargado de la gestión de productos")
                                .contact(
                                        new Contact()
                                                .name("Antonella Acevedo")
                                                .email("antonella@logistica.cl")
                                )
                );
    }
}