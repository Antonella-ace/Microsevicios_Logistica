package com.logistica.producto_service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Entity
@Table(name = "productos")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa un producto")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(
            description = "Identificador único del producto",
            example = "1"
    )
    private Long id;

    @NotBlank(message = "Nombre obligatorio")
    @Column(nullable = false)
    @Schema(
            description = "Nombre del producto",
            example = "Notebook Lenovo"
    )
    private String nombre;

    @NotBlank(message = "Categoría obligatoria")
    @Schema(
            description = "Categoría del producto",
            example = "Electrónica"
    )
    private String categoria;

    @NotNull(message = "Precio obligatorio")
    @Min(value = 1, message = "Precio debe ser mayor a 0")
    @Schema(
            description = "Precio del producto",
            example = "799990"
    )
    private Double precio;

    @NotNull(message = "Stock obligatorio")
    @Min(value = 0, message = "Stock no puede ser negativo")
    @Schema(
            description = "Cantidad disponible en stock",
            example = "50"
    )
    private Integer stock;

    @Schema(
            description = "Descripción del producto",
            example = "Notebook Lenovo IdeaPad 15 pulgadas"
    )
    private String descripcion;

    @Schema(
            description = "Indica si el producto está activo",
            example = "true"
    )
    private Boolean activo = true;
}