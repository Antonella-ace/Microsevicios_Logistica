package com.logistica.producto_service.service;

import com.logistica.producto_service.model.Producto;
import com.logistica.producto_service.repository.ProductoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ProductoServiceTest {

    @Mock
    private ProductoRepository repository;

    @InjectMocks
    private ProductoService service;

    @Test
    void deberiaRetornarListaProductos() {

        Producto producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Notebook");

        Mockito.when(repository.findAll())
                .thenReturn(List.of(producto));

        List<Producto> resultado = service.listar();

        assertEquals(1, resultado.size());
        assertEquals("Notebook", resultado.get(0).getNombre());

        verify(repository).findAll();
    }

    @Test
    void deberiaGuardarProducto() {

        Producto producto = new Producto();
        producto.setNombre("Mouse");

        Mockito.when(repository.save(producto))
                .thenReturn(producto);

        Producto resultado = service.guardar(producto);

        assertEquals("Mouse", resultado.getNombre());

        verify(repository).save(producto);
    }

    @Test
    void deberiaBuscarProductoPorId() {

        Producto producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Teclado");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(producto));

        Producto resultado = service.buscar(1L);

        assertEquals("Teclado", resultado.getNombre());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaActualizarProducto() {

        Producto producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Producto Viejo");

        Producto nuevo = new Producto();
        nuevo.setNombre("Producto Nuevo");
        nuevo.setCategoria("Electrónica");
        nuevo.setPrecio(1000.0);
        nuevo.setStock(10);
        nuevo.setDescripcion("Descripción");
        nuevo.setActivo(true);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(producto));

        Mockito.when(repository.save(producto))
                .thenReturn(producto);

        Producto resultado = service.actualizar(1L, nuevo);

        assertEquals("Producto Nuevo", resultado.getNombre());
        assertEquals("Electrónica", resultado.getCategoria());

        verify(repository).findById(1L);
        verify(repository).save(producto);
    }

    @Test
    void deberiaEliminarProducto() {

        Mockito.when(repository.existsById(1L))
                .thenReturn(true);

        service.eliminar(1L);

        verify(repository).existsById(1L);
        verify(repository).deleteById(1L);
    }
}