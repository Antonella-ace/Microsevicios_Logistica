package com.logistica.inventario_service.service;

import com.logistica.inventario_service.model.Inventario;
import com.logistica.inventario_service.repository.InventarioRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class InventarioServiceTest {

    @Mock
    private InventarioRepository repository;

    @InjectMocks
    private InventarioService service;

    @Test
    void deberiaListarInventario() {

        Inventario inventario = new Inventario();
        inventario.setId(1L);
        inventario.setStockActual(20);

        Mockito.when(repository.findAll())
                .thenReturn(List.of(inventario));

        List<Inventario> resultado = service.listar();

        assertEquals(1, resultado.size());
        assertEquals(20, resultado.get(0).getStockActual());

        verify(repository).findAll();
    }

    @Test
    void deberiaGuardarInventario() {

        Inventario inventario = new Inventario();
        inventario.setProductoId(1L);
        inventario.setStockActual(10);

        Mockito.when(repository.save(inventario))
                .thenReturn(inventario);

        Inventario resultado = service.guardar(inventario);

        assertEquals(10, resultado.getStockActual());

        verify(repository).save(inventario);
    }

    @Test
    void deberiaAgregarStock() {

        Inventario inventario = new Inventario();
        inventario.setId(1L);
        inventario.setStockActual(10);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(inventario));

        Mockito.when(repository.save(Mockito.any(Inventario.class)))
                .thenAnswer(i -> i.getArgument(0));

        Inventario resultado = service.entrada(1L, 5);

        assertEquals(15, resultado.getStockActual());

        verify(repository).findById(1L);
        verify(repository).save(inventario);
    }

    @Test
    void deberiaDescontarStock() {

        Inventario inventario = new Inventario();
        inventario.setId(1L);
        inventario.setStockActual(20);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(inventario));

        Mockito.when(repository.save(Mockito.any(Inventario.class)))
                .thenAnswer(i -> i.getArgument(0));

        Inventario resultado = service.salida(1L, 5);

        assertEquals(15, resultado.getStockActual());

        verify(repository).findById(1L);
        verify(repository).save(inventario);
    }
}