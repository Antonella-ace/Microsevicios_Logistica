package com.logistica.inventario_service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "inventario")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa el inventario de productos")
public class Inventario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "ID del inventario", example = "1")
    private Long id;

    @Schema(description = "ID del producto asociado", example = "10")
    private Long productoId;

    @Schema(description = "Stock actual disponible", example = "50")
    private Integer stockActual;

    @Schema(description = "Stock mínimo permitido", example = "10")
    private Integer stockMinimo;

    @Schema(description = "Ubicación física del inventario", example = "Bodega Central")
    private String ubicacion;
}