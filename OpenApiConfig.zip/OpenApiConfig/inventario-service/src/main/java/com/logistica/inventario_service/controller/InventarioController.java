package com.logistica.inventario_service.controller;

import com.logistica.inventario_service.model.Inventario;
import com.logistica.inventario_service.service.InventarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventario")
@RequiredArgsConstructor
public class InventarioController {

    private final InventarioService service;

    @Operation(
            summary = "Listar inventario",
            description = "Obtiene todos los registros de inventario"
    )
    @ApiResponse(responseCode = "200", description = "Listado obtenido correctamente")
    @GetMapping
    public List<Inventario> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Registrar inventario",
            description = "Crea un nuevo registro de inventario"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Inventario registrado"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public Inventario guardar(@Valid @RequestBody Inventario inventario) {
        return service.guardar(inventario);
    }

    @Operation(
            summary = "Entrada de stock",
            description = "Aumenta el stock de un producto"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Stock actualizado"),
            @ApiResponse(responseCode = "404", description = "Inventario no encontrado")
    })
    @PatchMapping("/{id}/entrada/{cantidad}")
    public Inventario entrada(
            @PathVariable Long id,
            @PathVariable Integer cantidad) {

        return service.entrada(id, cantidad);
    }

    @Operation(
            summary = "Salida de stock",
            description = "Disminuye el stock de un producto"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Stock actualizado"),
            @ApiResponse(responseCode = "404", description = "Inventario no encontrado"),
            @ApiResponse(responseCode = "400", description = "Stock insuficiente")
    })
    @PatchMapping("/{id}/salida/{cantidad}")
    public Inventario salida(
            @PathVariable Long id,
            @PathVariable Integer cantidad) {

        return service.salida(id, cantidad);
    }
}