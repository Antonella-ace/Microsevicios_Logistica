package com.logistica.usuario_service.service;

import com.logistica.usuario_service.model.Usuario;
import com.logistica.usuario_service.repository.UsuarioRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class UsuarioServiceTest {

    @Mock
    private UsuarioRepository repository;

    @InjectMocks
    private UsuarioService service;

    @Test
    void deberiaRetornarListaUsuarios() {

        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombre("Juan");
        usuario.setCorreo("juan@gmail.com");

        Mockito.when(repository.findAll())
                .thenReturn(List.of(usuario));

        List<Usuario> resultado = service.listar();

        assertEquals(1, resultado.size());
        assertEquals("Juan", resultado.get(0).getNombre());

        verify(repository).findAll();
    }
    @Test
    void deberiaGuardarUsuario() {

        Usuario usuario = new Usuario();
        usuario.setNombre("Juan");
        usuario.setCorreo("juan@gmail.com");
        usuario.setPassword("1234");
        usuario.setRol("ADMIN");

        Mockito.when(repository.findByCorreo("juan@gmail.com"))
                .thenReturn(java.util.Optional.empty());

        Mockito.when(repository.save(usuario))
                .thenReturn(usuario);

        Usuario resultado = service.guardar(usuario);

        assertEquals("Juan", resultado.getNombre());

        verify(repository).findByCorreo("juan@gmail.com");
        verify(repository).save(usuario);
    }
    @Test
    void deberiaRetornarUsuarioCuandoExiste() {

        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombre("Juan");
        usuario.setCorreo("juan@gmail.com");

        Mockito.when(repository.findByCorreo("juan@gmail.com"))
                .thenReturn(java.util.Optional.of(usuario));

        Usuario resultado = service.login("juan@gmail.com");

        assertEquals("Juan", resultado.getNombre());

        verify(repository).findByCorreo("juan@gmail.com");
    }
    @Test
    void deberiaLanzarExcepcionSiCorreoExiste() {

        Usuario usuario = new Usuario();
        usuario.setCorreo("juan@gmail.com");

        Mockito.when(repository.findByCorreo("juan@gmail.com"))
                .thenReturn(java.util.Optional.of(usuario));

        RuntimeException exception =
                org.junit.jupiter.api.Assertions.assertThrows(
                        RuntimeException.class,
                        () -> service.guardar(usuario)
                );

        assertEquals("Correo ya registrado", exception.getMessage());

        verify(repository).findByCorreo("juan@gmail.com");
    }
}