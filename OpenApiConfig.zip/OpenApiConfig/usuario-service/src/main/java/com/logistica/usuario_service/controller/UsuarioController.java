package com.logistica.usuario_service.controller;

import com.logistica.usuario_service.model.Usuario;
import com.logistica.usuario_service.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
@SecurityRequirement(name = "bearerAuth")
public class UsuarioController {

    private final UsuarioService service;
    @Operation ( summary = "crear usuario",
    description = "registra nuevo usuario")
    @ApiResponses( value= {
            @ApiResponse(
                    responseCode = "201",
                    description = "usuario creado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos inválidos"
            ),
            @ApiResponse(
                    responseCode = "401",
                    description = "No autenticado"
            ),
            @ApiResponse(
                    responseCode = "403",
                    description = "Sin permisos"
            )
    })
    @PostMapping
    public ResponseEntity<Usuario> save(@Valid @RequestBody Usuario usuario)
    {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(service.guardar(usuario));
    }

    public UsuarioController(UsuarioService service) {
        this.service = service;
    }

    @GetMapping
    public List<Usuario> listar() {
        return service.listar();
    }

    @PostMapping
    public Usuario guardar(@Valid @RequestBody Usuario usuario) {
        return service.guardar(usuario);
    }

    @GetMapping("/buscar/{correo}")
    public Usuario buscar(@PathVariable String correo){
        return service.login(correo);
    }

}