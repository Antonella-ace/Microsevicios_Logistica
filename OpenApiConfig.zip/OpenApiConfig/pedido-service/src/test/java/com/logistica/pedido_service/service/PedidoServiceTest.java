package com.logistica.pedido_service.service;

import com.logistica.pedido_service.model.Pedido;
import com.logistica.pedido_service.repository.PedidoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class PedidoServiceTest {

    @Mock
    private PedidoRepository repository;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private PedidoService service;

    @Test
    void deberiaListarPedidos() {

        Pedido pedido = new Pedido();
        pedido.setId(1L);
        pedido.setCliente("Juan");

        Mockito.when(repository.findAll())
                .thenReturn(List.of(pedido));

        List<Pedido> resultado = service.listar();

        assertEquals(1, resultado.size());
        assertEquals("Juan", resultado.get(0).getCliente());

        verify(repository).findAll();
    }

    @Test
    void deberiaGuardarPedido() {

        Pedido pedido = new Pedido();
        pedido.setProductoId(1L);
        pedido.setCantidad(2);
        pedido.setCliente("Pedro");
        pedido.setDireccion("Melipilla");

        Mockito.when(repository.save(Mockito.any(Pedido.class)))
                .thenAnswer(i -> i.getArgument(0));

        Pedido resultado = service.guardar(pedido);

        assertEquals("ENVIADO", resultado.getEstado());
        assertNotNull(resultado.getFecha());

        verify(repository).save(pedido);
    }

    @Test
    void deberiaLanzarErrorCuandoFallaProceso() {

        Pedido pedido = new Pedido();
        pedido.setCantidad(2);

        Mockito.doThrow(new RuntimeException())
                .when(restTemplate)
                .patchForObject(
                        Mockito.anyString(),
                        Mockito.isNull(),
                        Mockito.eq(Object.class)
                );

        RuntimeException ex = assertThrows(
                RuntimeException.class,
                () -> service.guardar(pedido)
        );

        assertEquals(
                "Error al procesar pedido",
                ex.getMessage()
        );
    }
}