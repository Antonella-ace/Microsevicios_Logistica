package com.logistica.pedido_service.controller;

import com.logistica.pedido_service.model.Pedido;
import com.logistica.pedido_service.service.PedidoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pedidos")
@RequiredArgsConstructor
public class PedidoController {

    private final PedidoService service;

    @Operation(
            summary = "Listar pedidos",
            description = "Obtiene todos los pedidos registrados"
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado obtenido correctamente"
    )
    @GetMapping
    public List<Pedido> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Crear pedido",
            description = "Genera un pedido y descuenta stock del inventario"
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Pedido creado correctamente"
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Error al procesar pedido"
            )
    })
    @PostMapping
    public Pedido guardar(@Valid @RequestBody Pedido pedido) {
        return service.guardar(pedido);
    }
}