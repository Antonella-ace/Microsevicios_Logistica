package com.logistica.pedido_service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "pedidos")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Información de los pedidos")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "ID del pedido", example = "1")
    private Long id;

    @NotNull(message = "ProductoId obligatorio")
    @Schema(description = "ID del producto solicitado", example = "5")
    private Long productoId;

    @NotNull(message = "Cantidad obligatoria")
    @Min(value = 1, message = "Cantidad debe ser mayor a 0")
    @Schema(description = "Cantidad solicitada", example = "3")
    private Integer cantidad;

    @NotBlank(message = "Cliente obligatorio")
    @Schema(description = "Nombre del cliente", example = "Juan Pérez")
    private String cliente;

    @NotBlank(message = "Dirección obligatoria")
    @Schema(description = "Dirección de entrega", example = "Melipilla")
    private String direccion;

    @Schema(description = "Estado del pedido", example = "PENDIENTE")
    private String estado = "PENDIENTE";

    @Schema(description = "Fecha de creación del pedido")
    private LocalDateTime fecha;
}