package com.logistica.carrito_service.service;

import com.logistica.carrito_service.model.Carrito;
import com.logistica.carrito_service.repository.CarritoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CarritoServiceTest {

    @Mock
    private CarritoRepository repository;

    @InjectMocks
    private CarritoService service;

    @Test
    void deberiaListarCarrito() {

        Carrito carrito = new Carrito();
        carrito.setId(1L);
        carrito.setUsuarioId(1L);
        carrito.setProductoId(2L);
        carrito.setCantidad(3);

        Mockito.when(repository.findAll())
                .thenReturn(List.of(carrito));

        List<Carrito> resultado = service.listar();

        assertEquals(1, resultado.size());
        assertEquals(3, resultado.get(0).getCantidad());

        verify(repository).findAll();
    }

    @Test
    void deberiaBuscarCarritoPorId() {

        Carrito carrito = new Carrito();
        carrito.setId(1L);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(carrito));

        Carrito resultado = service.buscar(1L);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaGuardarCarrito() {

        Carrito carrito = new Carrito();
        carrito.setUsuarioId(1L);
        carrito.setProductoId(2L);
        carrito.setCantidad(2);

        Mockito.when(repository.save(carrito))
                .thenReturn(carrito);

        Carrito resultado = service.guardar(carrito);

        assertEquals(2, resultado.getCantidad());

        verify(repository).save(carrito);
    }

    @Test
    void deberiaSumarCantidad() {

        Carrito carrito = new Carrito();
        carrito.setId(1L);
        carrito.setCantidad(2);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(carrito));

        Mockito.when(repository.save(Mockito.any(Carrito.class)))
                .thenReturn(carrito);

        Carrito resultado = service.sumarCantidad(1L, 3);

        assertEquals(5, resultado.getCantidad());

        verify(repository).findById(1L);
        verify(repository).save(carrito);
    }

    @Test
    void deberiaEliminarCarrito() {

        Carrito carrito = new Carrito();
        carrito.setId(1L);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(carrito));

        service.eliminar(1L);

        verify(repository).delete(carrito);
    }

    @Test
    void deberiaVaciarCarrito() {

        service.vaciar();

        verify(repository).deleteAll();
    }
}