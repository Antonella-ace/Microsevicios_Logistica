package com.logistica.carrito_service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name="carrito")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa un producto agregado al carrito de compras")
public class Carrito {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único del registro del carrito", example = "1")
    private Long id;

    @NotNull(message = "Usuario obligatorio")
    @Schema(description = "ID del usuario propietario del carrito", example = "10")
    private Long usuarioId;

    @NotNull(message = "Producto obligatorio")
    @Schema(description = "ID del producto agregado al carrito", example = "5")
    private Long productoId;

    @NotNull(message = "Cantidad obligatoria")
    @Min(value = 1, message = "Cantidad mínima 1")
    @Schema(description = "Cantidad de productos agregados", example = "2")
    private Integer cantidad;
}