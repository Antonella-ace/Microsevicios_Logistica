package com.logistica.carrito_service.controller;

import com.logistica.carrito_service.model.Carrito;
import com.logistica.carrito_service.service.CarritoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/carrito")
@RequiredArgsConstructor
public class CarritoController {

    private final CarritoService service;

    @Operation(
            summary = "Listar carrito",
            description = "Obtiene todos los registros del carrito"
    )
    @ApiResponse(responseCode = "200", description = "Listado obtenido correctamente")
    @GetMapping
    public List<Carrito> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Buscar producto en carrito",
            description = "Busca un registro del carrito por ID"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Registro encontrado"),
            @ApiResponse(responseCode = "404", description = "Registro no encontrado")
    })
    @GetMapping("/{id}")
    public Carrito buscar(@PathVariable Long id) {
        return service.buscar(id);
    }

    @Operation(
            summary = "Agregar al carrito",
            description = "Agrega un producto al carrito"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Producto agregado"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public Carrito guardar(@Valid @RequestBody Carrito c) {
        return service.guardar(c);
    }

    @Operation(
            summary = "Actualizar carrito",
            description = "Actualiza un registro existente del carrito"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Registro actualizado"),
            @ApiResponse(responseCode = "404", description = "Registro no encontrado")
    })
    @PutMapping("/{id}")
    public Carrito actualizar(@PathVariable Long id,
                              @Valid @RequestBody Carrito c) {
        return service.actualizar(id, c);
    }

    @Operation(
            summary = "Sumar cantidad",
            description = "Incrementa la cantidad de productos en el carrito"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Cantidad actualizada"),
            @ApiResponse(responseCode = "404", description = "Registro no encontrado")
    })
    @PatchMapping("/{id}/sumar/{cantidad}")
    public Carrito sumar(@PathVariable Long id,
                         @PathVariable Integer cantidad) {
        return service.sumarCantidad(id, cantidad);
    }

    @Operation(
            summary = "Eliminar producto del carrito",
            description = "Elimina un registro del carrito por ID"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Registro eliminado"),
            @ApiResponse(responseCode = "404", description = "Registro no encontrado")
    })
    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }

    @Operation(
            summary = "Vaciar carrito",
            description = "Elimina todos los registros del carrito"
    )
    @ApiResponse(responseCode = "200", description = "Carrito vaciado correctamente")
    @DeleteMapping("/vaciar")
    public void vaciar() {
        service.vaciar();
    }
}