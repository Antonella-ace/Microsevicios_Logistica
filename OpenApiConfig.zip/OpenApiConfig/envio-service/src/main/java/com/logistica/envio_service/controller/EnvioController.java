package com.logistica.envio_service.controller;

import com.logistica.envio_service.dto.EnvioRequest;
import com.logistica.envio_service.model.Envio;
import com.logistica.envio_service.service.EnvioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/envios")
@RequiredArgsConstructor
public class EnvioController {

    private final EnvioService service;

    @Operation(
            summary = "Listar envíos",
            description = "Obtiene todos los envíos registrados"
    )
    @GetMapping
    public List<Envio> listar() {
        return service.findAll();
    }

    @Operation(
            summary = "Buscar envío",
            description = "Busca un envío por ID"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Envío encontrado"),
            @ApiResponse(responseCode = "404", description = "Envío no encontrado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Envio> buscar(@PathVariable Long id) {

        Envio envio = service.findById(id);

        if (envio != null) {
            return ResponseEntity.ok(envio);
        }

        return ResponseEntity.notFound().build();
    }

    @Operation(
            summary = "Crear envío",
            description = "Registra un nuevo envío"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Envío creado"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public ResponseEntity<?> guardar(@Valid @RequestBody EnvioRequest request) {

        Envio envio = new Envio();

        envio.setDestino(request.getDireccion());
        envio.setPeso(request.getPeso());
        envio.setTipo(request.getTipo());

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.save(envio));
    }

    @Operation(
            summary = "Marcar como entregado",
            description = "Actualiza el estado del envío a ENTREGADO"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Envío entregado"),
            @ApiResponse(responseCode = "404", description = "Envío no encontrado")
    })
    @PatchMapping("/{id}/entregar")
    public ResponseEntity<Envio> entregar(@PathVariable Long id) {

        Envio envio = service.marcarEntregado(id);

        if (envio != null) {
            return ResponseEntity.ok(envio);
        }

        return ResponseEntity.notFound().build();
    }
}