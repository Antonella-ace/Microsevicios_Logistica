package com.logistica.envio_service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "envios")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Información de los envíos")
public class Envio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "ID del envío", example = "1")
    private Long id;

    @Column(nullable = false)
    @Schema(description = "Destino del envío", example = "Melipilla")
    private String destino;

    @Schema(description = "Peso del paquete", example = "5")
    private Integer peso;

    @Schema(description = "Tipo de envío", example = "EXPRESS")
    private String tipo;

    @Schema(description = "Indica si fue entregado", example = "false")
    private Boolean entregado = false;

    @Schema(description = "Estado del envío", example = "PENDIENTE")
    private String estado = "PENDIENTE";

    @Schema(description = "Costo del envío", example = "25.0")
    private Double costoEnvio;

    @Schema(description = "Fecha de creación")
    private LocalDateTime fechaCreacion;

    @Schema(description = "Código de seguimiento", example = "ENV-ABC12345")
    private String codigoSeguimiento;
}