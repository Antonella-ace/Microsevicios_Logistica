package com.logistica.envio_service.service;

import com.logistica.envio_service.model.Envio;
import com.logistica.envio_service.repository.EnvioRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class EnvioServiceTest {

    @Mock
    private EnvioRepository repository;

    @InjectMocks
    private EnvioService service;

    @Test
    void deberiaListarEnvios() {

        Envio envio = new Envio();
        envio.setId(1L);
        envio.setDestino("Melipilla");

        Mockito.when(repository.findAll())
                .thenReturn(List.of(envio));

        List<Envio> resultado = service.findAll();

        assertEquals(1, resultado.size());
        assertEquals("Melipilla", resultado.get(0).getDestino());

        verify(repository).findAll();
    }

    @Test
    void deberiaBuscarEnvioPorId() {

        Envio envio = new Envio();
        envio.setId(1L);
        envio.setDestino("Santiago");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(envio));

        Envio resultado = service.findById(1L);

        assertEquals("Santiago", resultado.getDestino());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaGuardarEnvio() {

        Envio envio = new Envio();
        envio.setDestino("Melipilla");
        envio.setPeso(4);
        envio.setTipo("NORMAL");

        Mockito.when(repository.save(Mockito.any(Envio.class)))
                .thenAnswer(i -> i.getArgument(0));

        Envio resultado = service.save(envio);

        assertEquals("PENDIENTE", resultado.getEstado());
        assertFalse(resultado.getEntregado());

        assertNotNull(resultado.getFechaCreacion());
        assertNotNull(resultado.getCodigoSeguimiento());
        assertNotNull(resultado.getCostoEnvio());

        verify(repository).save(envio);
    }

    @Test
    void deberiaMarcarEnvioComoEntregado() {

        Envio envio = new Envio();
        envio.setId(1L);
        envio.setEstado("PENDIENTE");
        envio.setEntregado(false);

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(envio));

        Mockito.when(repository.save(Mockito.any(Envio.class)))
                .thenAnswer(i -> i.getArgument(0));

        Envio resultado = service.marcarEntregado(1L);

        assertTrue(resultado.getEntregado());
        assertEquals("ENTREGADO", resultado.getEstado());

        verify(repository).findById(1L);
        verify(repository).save(envio);
    }
}