package com.logistica.proveedor_service.controller;

import com.logistica.proveedor_service.model.Proveedor;
import com.logistica.proveedor_service.service.ProveedorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/proveedores")
public class ProveedorController {

    private final ProveedorService service;

    public ProveedorController(ProveedorService service) {
        this.service = service;
    }

    @Operation(
            summary = "Listar proveedores",
            description = "Obtiene todos los proveedores registrados"
    )
    @ApiResponse(responseCode = "200", description = "Listado obtenido correctamente")
    @GetMapping
    public List<Proveedor> listar() {
        return service.listar();
    }

    @Operation(
            summary = "Buscar proveedor",
            description = "Busca un proveedor por ID"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Proveedor encontrado"),
            @ApiResponse(responseCode = "404", description = "Proveedor no encontrado")
    })
    @GetMapping("/{id}")
    public Proveedor buscar(@PathVariable Long id) {
        return service.buscar(id);
    }

    @Operation(
            summary = "Crear proveedor",
            description = "Registra un nuevo proveedor"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Proveedor creado"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public Proveedor guardar(@Valid @RequestBody Proveedor proveedor) {
        return service.guardar(proveedor);
    }

    @Operation(
            summary = "Actualizar proveedor",
            description = "Actualiza los datos de un proveedor existente"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Proveedor actualizado"),
            @ApiResponse(responseCode = "404", description = "Proveedor no encontrado")
    })
    @PutMapping("/{id}")
    public Proveedor actualizar(@PathVariable Long id,
                                @Valid @RequestBody Proveedor proveedor) {
        return service.actualizar(id, proveedor);
    }

    @Operation(
            summary = "Eliminar proveedor",
            description = "Elimina un proveedor por ID"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Proveedor eliminado"),
            @ApiResponse(responseCode = "404", description = "Proveedor no encontrado")
    })
    @DeleteMapping("/{id}")
    public String eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return "Proveedor eliminado";
    }
}