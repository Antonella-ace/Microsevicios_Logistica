package com.logistica.proveedor_service.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "proveedores")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Entidad que representa un proveedor de productos")
public class Proveedor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único del proveedor", example = "1")
    private Long id;

    @NotBlank(message = "Nombre obligatorio")
    @Schema(description = "Nombre del proveedor", example = "Distribuidora Central")
    private String nombre;

    @NotBlank(message = "Telefono obligatorio")
    @Schema(description = "Teléfono de contacto", example = "+56912345678")
    private String telefono;

    @Email(message = "Correo inválido")
    @Schema(description = "Correo electrónico del proveedor", example = "contacto@proveedor.cl")
    private String correo;

    @NotBlank(message = "Direccion obligatoria")
    @Schema(description = "Dirección del proveedor", example = "Av. Principal 123, Santiago")
    private String direccion;
}