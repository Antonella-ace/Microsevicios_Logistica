package com.logistica.proveedor_service.service;

import com.logistica.proveedor_service.model.Proveedor;
import com.logistica.proveedor_service.repository.ProveedorRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ProveedorServiceTest {

    @Mock
    private ProveedorRepository repository;

    @InjectMocks
    private ProveedorService service;

    @Test
    void deberiaListarProveedores() {

        Proveedor proveedor = new Proveedor();
        proveedor.setId(1L);
        proveedor.setNombre("Proveedor 1");

        Mockito.when(repository.findAll())
                .thenReturn(List.of(proveedor));

        List<Proveedor> resultado = service.listar();

        assertEquals(1, resultado.size());
        assertEquals("Proveedor 1", resultado.get(0).getNombre());

        verify(repository).findAll();
    }

    @Test
    void deberiaGuardarProveedor() {

        Proveedor proveedor = new Proveedor();
        proveedor.setNombre("Proveedor Nuevo");

        Mockito.when(repository.save(proveedor))
                .thenReturn(proveedor);

        Proveedor resultado = service.guardar(proveedor);

        assertEquals("Proveedor Nuevo", resultado.getNombre());

        verify(repository).save(proveedor);
    }

    @Test
    void deberiaBuscarProveedorPorId() {

        Proveedor proveedor = new Proveedor();
        proveedor.setId(1L);
        proveedor.setNombre("Proveedor Test");

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(proveedor));

        Proveedor resultado = service.buscar(1L);

        assertEquals("Proveedor Test", resultado.getNombre());

        verify(repository).findById(1L);
    }

    @Test
    void deberiaActualizarProveedor() {

        Proveedor existente = new Proveedor(
                1L,
                "Proveedor Viejo",
                "11111111",
                "viejo@gmail.com",
                "Direccion Vieja"
        );

        Proveedor nuevo = new Proveedor(
                null,
                "Proveedor Nuevo",
                "99999999",
                "nuevo@gmail.com",
                "Direccion Nueva"
        );

        Mockito.when(repository.findById(1L))
                .thenReturn(Optional.of(existente));

        Mockito.when(repository.save(Mockito.any(Proveedor.class)))
                .thenAnswer(i -> i.getArgument(0));

        Proveedor resultado = service.actualizar(1L, nuevo);

        assertEquals("Proveedor Nuevo", resultado.getNombre());
        assertEquals("99999999", resultado.getTelefono());
        assertEquals("nuevo@gmail.com", resultado.getCorreo());

        verify(repository).findById(1L);
        verify(repository).save(existente);
    }

    @Test
    void deberiaEliminarProveedor() {

        service.eliminar(1L);

        verify(repository).deleteById(1L);
    }
}