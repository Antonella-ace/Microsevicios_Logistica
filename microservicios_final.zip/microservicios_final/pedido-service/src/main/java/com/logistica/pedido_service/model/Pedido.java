package com.logistica.pedido_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "pedidos")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "ProductoId obligatorio")
    private Long productoId;

    @NotNull(message = "Cantidad obligatoria")
    @Min(value = 1, message = "Cantidad debe ser mayor a 0")
    private Integer cantidad;

    @NotBlank(message = "Cliente obligatorio")
    private String cliente;

    @NotBlank(message = "Dirección obligatoria")
    private String direccion;

    private String estado = "PENDIENTE";

    private LocalDateTime fecha;
}