package com.logistica.carrito_service.controller;

import com.logistica.carrito_service.model.Carrito;
import com.logistica.carrito_service.service.CarritoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/carrito")
@RequiredArgsConstructor
public class CarritoController {

    private final CarritoService service;

    @GetMapping
    public List<Carrito> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Carrito buscar(@PathVariable Long id) {
        return service.buscar(id);
    }

    @PostMapping
    public Carrito guardar(@Valid @RequestBody Carrito c) {
        return service.guardar(c);
    }

    @PutMapping("/{id}")
    public Carrito actualizar(@PathVariable Long id,
                              @Valid @RequestBody Carrito c) {
        return service.actualizar(id, c);
    }

    @PatchMapping("/{id}/sumar/{cantidad}")
    public Carrito sumar(@PathVariable Long id,
                         @PathVariable Integer cantidad) {
        return service.sumarCantidad(id, cantidad);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }

    @DeleteMapping("/vaciar")
    public void vaciar() {
        service.vaciar();
    }
}