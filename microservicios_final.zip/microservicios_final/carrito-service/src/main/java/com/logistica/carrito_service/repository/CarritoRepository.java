package com.logistica.carrito_service.repository;

import com.logistica.carrito_service.model.Carrito;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarritoRepository extends JpaRepository<Carrito, Long> {
}