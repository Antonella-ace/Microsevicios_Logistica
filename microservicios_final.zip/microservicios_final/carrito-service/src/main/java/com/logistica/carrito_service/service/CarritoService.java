package com.logistica.carrito_service.service;

import com.logistica.carrito_service.model.Carrito;
import com.logistica.carrito_service.repository.CarritoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CarritoService {

    private final CarritoRepository repository;

    public List<Carrito> listar() {
        return repository.findAll();
    }

    public Carrito buscar(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Producto en carrito no encontrado"));
    }

    public Carrito guardar(Carrito c) {
        return repository.save(c);
    }

    public Carrito actualizar(Long id, Carrito nuevo) {

        Carrito carrito = buscar(id);

        carrito.setUsuarioId(nuevo.getUsuarioId());
        carrito.setProductoId(nuevo.getProductoId());
        carrito.setCantidad(nuevo.getCantidad());

        return repository.save(carrito);
    }

    public Carrito sumarCantidad(Long id, Integer cantidad) {

        Carrito carrito = buscar(id);

        carrito.setCantidad(carrito.getCantidad() + cantidad);

        return repository.save(carrito);
    }

    public void eliminar(Long id) {

        Carrito carrito = buscar(id);

        repository.delete(carrito);
    }

    public void vaciar() {
        repository.deleteAll();
    }
}