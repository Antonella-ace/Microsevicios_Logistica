package com.logistica.notificacion_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name="notificaciones")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Notificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Mensaje obligatorio")
    private String mensaje;

    @NotBlank(message = "Destinatario obligatorio")
    private String destinatario;

    private String estado = "PENDIENTE";
}