package com.logistica.notificacion_service.repository;

import com.logistica.notificacion_service.model.Notificacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {
}