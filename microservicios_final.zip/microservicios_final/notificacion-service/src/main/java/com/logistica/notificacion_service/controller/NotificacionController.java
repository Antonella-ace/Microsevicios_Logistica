package com.logistica.notificacion_service.controller;

import com.logistica.notificacion_service.model.Notificacion;
import com.logistica.notificacion_service.service.NotificacionService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notificaciones")
public class NotificacionController {

    private final NotificacionService service;

    public NotificacionController(NotificacionService service) {
        this.service = service;
    }

    @GetMapping
    public List<Notificacion> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Notificacion buscar(@PathVariable Long id) {
        return service.buscar(id);
    }

    @PostMapping
    public Notificacion guardar(@Valid @RequestBody Notificacion n) {
        return service.guardar(n);
    }

    @PutMapping("/{id}")
    public Notificacion actualizar(@PathVariable Long id,
                                   @Valid @RequestBody Notificacion n) {
        return service.actualizar(id, n);
    }

    @PatchMapping("/{id}/enviar")
    public Notificacion enviar(@PathVariable Long id) {
        return service.enviar(id);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}