package com.logistica.notificacion_service.service;

import com.logistica.notificacion_service.model.Notificacion;
import com.logistica.notificacion_service.repository.NotificacionRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificacionService {

    private final NotificacionRepository repository;

    public NotificacionService(NotificacionRepository repository) {
        this.repository = repository;
    }

    public List<Notificacion> listar() {
        return repository.findAll();
    }

    public Notificacion buscar(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Notificación no encontrada"));
    }

    public Notificacion guardar(Notificacion n) {
        n.setEstado("PENDIENTE");
        return repository.save(n);
    }

    public Notificacion actualizar(Long id, Notificacion nueva) {

        Notificacion n = buscar(id);

        n.setMensaje(nueva.getMensaje());
        n.setDestinatario(nueva.getDestinatario());
        n.setEstado(nueva.getEstado());

        return repository.save(n);
    }

    public Notificacion enviar(Long id) {

        Notificacion n = buscar(id);

        n.setEstado("ENVIADA");

        return repository.save(n);
    }

    public void eliminar(Long id) {

        Notificacion n = buscar(id);

        repository.delete(n);
    }
}