package com.logistica.pago_service.service;

import com.logistica.pago_service.model.Pago;
import com.logistica.pago_service.repository.PagoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PagoService {

    private final PagoRepository repository;

    public List<Pago> listar() {
        return repository.findAll();
    }

    public Pago buscar(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pago no encontrado"));
    }

    public Pago guardar(Pago pago) {
        pago.setEstado("PENDIENTE");
        return repository.save(pago);
    }

    public Pago actualizar(Long id, Pago nuevoPago) {

        Pago pago = buscar(id);

        pago.setPedidoId(nuevoPago.getPedidoId());
        pago.setMonto(nuevoPago.getMonto());
        pago.setMetodoPago(nuevoPago.getMetodoPago());
        pago.setEstado(nuevoPago.getEstado());

        return repository.save(pago);
    }

    public Pago pagar(Long id) {

        Pago pago = buscar(id);

        pago.setEstado("PAGADO");

        return repository.save(pago);
    }

    public void eliminar(Long id) {

        Pago pago = buscar(id);

        repository.delete(pago);
    }
}