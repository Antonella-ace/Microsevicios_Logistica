package com.logistica.pago_service.controller;

import com.logistica.pago_service.model.Pago;
import com.logistica.pago_service.service.PagoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pagos")
@RequiredArgsConstructor
public class PagoController {

    private final PagoService service;

    @GetMapping
    public List<Pago> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Pago buscar(@PathVariable Long id) {
        return service.buscar(id);
    }

    @PostMapping
    public Pago guardar(@Valid @RequestBody Pago pago) {
        return service.guardar(pago);
    }

    @PutMapping("/{id}")
    public Pago actualizar(@PathVariable Long id,
                           @Valid @RequestBody Pago pago) {
        return service.actualizar(id, pago);
    }

    @PatchMapping("/{id}/pagar")
    public Pago pagar(@PathVariable Long id) {
        return service.pagar(id);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}