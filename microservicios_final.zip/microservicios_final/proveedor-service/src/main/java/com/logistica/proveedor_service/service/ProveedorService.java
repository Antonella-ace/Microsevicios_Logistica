package com.logistica.proveedor_service.service;

import com.logistica.proveedor_service.model.Proveedor;
import com.logistica.proveedor_service.repository.ProveedorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProveedorService {

    private final ProveedorRepository repository;

    public ProveedorService(ProveedorRepository repository) {
        this.repository = repository;
    }

    public List<Proveedor> listar() {
        return repository.findAll();
    }

    public Proveedor guardar(Proveedor proveedor) {
        return repository.save(proveedor);
    }

    public Proveedor buscar(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Proveedor no encontrado"));
    }

    public Proveedor actualizar(Long id, Proveedor proveedor) {
        Proveedor p = buscar(id);
        p.setNombre(proveedor.getNombre());
        p.setTelefono(proveedor.getTelefono());
        p.setCorreo(proveedor.getCorreo());
        p.setDireccion(proveedor.getDireccion());
        return repository.save(p);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}