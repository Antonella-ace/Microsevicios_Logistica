package com.logistica.proveedor_service.repository;

import com.logistica.proveedor_service.model.Proveedor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProveedorRepository extends JpaRepository<Proveedor, Long> {
}