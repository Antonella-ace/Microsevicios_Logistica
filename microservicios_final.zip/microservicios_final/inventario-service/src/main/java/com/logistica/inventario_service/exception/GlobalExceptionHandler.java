package com.logistica.inventario_service.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String,String> manejarRuntime(RuntimeException ex){

        Map<String,String> error = new HashMap<>();
        error.put("error", ex.getMessage());

        return error;
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String,String> validar(MethodArgumentNotValidException ex){

        Map<String,String> error = new HashMap<>();

        ex.getBindingResult().getFieldErrors().forEach(e ->
                error.put(e.getField(), e.getDefaultMessage())
        );

        return error;
    }
}