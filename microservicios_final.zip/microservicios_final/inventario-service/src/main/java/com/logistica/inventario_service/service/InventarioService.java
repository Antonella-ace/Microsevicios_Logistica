package com.logistica.inventario_service.service;

import com.logistica.inventario_service.model.Inventario;
import com.logistica.inventario_service.repository.InventarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class InventarioService {

    private final InventarioRepository repository;

    public List<Inventario> listar() {
        return repository.findAll();
    }

    public Inventario guardar(Inventario inventario) {
        return repository.save(inventario);
    }

    public Inventario entrada(Long id, Integer cantidad) {

        Inventario inv = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Inventario no encontrado"));

        if (cantidad <= 0) {
            throw new RuntimeException("Cantidad debe ser mayor a 0");
        }

        inv.setStockActual(inv.getStockActual() + cantidad);

        return repository.save(inv);
    }

    public Inventario salida(Long id, Integer cantidad) {

        Inventario inv = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Inventario no encontrado"));

        if (cantidad <= 0) {
            throw new RuntimeException("Cantidad debe ser mayor a 0");
        }

        if (inv.getStockActual() < cantidad) {
            throw new RuntimeException("Stock insuficiente");
        }

        inv.setStockActual(inv.getStockActual() - cantidad);

        return repository.save(inv);
    }
}