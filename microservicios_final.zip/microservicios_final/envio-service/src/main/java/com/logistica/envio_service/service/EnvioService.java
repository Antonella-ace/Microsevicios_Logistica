package com.logistica.envio_service.service;

import com.logistica.envio_service.model.Envio;
import com.logistica.envio_service.repository.EnvioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class EnvioService {

    private final EnvioRepository repository;

    public List<Envio> findAll() {
        return repository.findAll();
    }

    public Envio findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Envío no encontrado"));
    }

    public Envio save(Envio envio) {

        envio.setFechaCreacion(LocalDateTime.now());
        envio.setCodigoSeguimiento(generarCodigo());
        envio.setCostoEnvio(calcularCosto(envio.getPeso()));
        envio.setEstado("PENDIENTE");
        envio.setEntregado(false);

        return repository.save(envio);
    }

    public Envio marcarEntregado(Long id) {

        Envio envio = findById(id);

        envio.setEntregado(true);
        envio.setEstado("ENTREGADO");

        return repository.save(envio);
    }

    private String generarCodigo() {
        return "ENV-" + UUID.randomUUID()
                .toString()
                .substring(0,8)
                .toUpperCase();
    }

    private Double calcularCosto(Integer peso) {

        if (peso == null) peso = 1;

        return 10.0 + (peso * 2.5);
    }
}