package com.logistica.envio_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnvioDTO {

    private String destino;
    private Integer peso;
    private String tipo;

    private Long id;
    private String estado;
    private Double costoEnvio;
    private String codigoSeguimiento;
}