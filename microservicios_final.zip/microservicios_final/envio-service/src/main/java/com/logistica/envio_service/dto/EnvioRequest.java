package com.logistica.envio_service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class EnvioRequest {

    @NotBlank(message = "La dirección es obligatoria")
    private String direccion;

    @NotNull(message = "El peso es obligatorio")
    private Integer peso;

    @NotBlank(message = "El tipo es obligatorio")
    private String tipo;
}