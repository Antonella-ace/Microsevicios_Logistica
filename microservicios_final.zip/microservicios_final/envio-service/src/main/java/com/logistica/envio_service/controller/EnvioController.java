package com.logistica.envio_service.controller;

import com.logistica.envio_service.dto.EnvioRequest;
import com.logistica.envio_service.model.Envio;
import com.logistica.envio_service.service.EnvioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/envios")
@RequiredArgsConstructor
public class EnvioController {

    private final EnvioService service;

    @GetMapping
    public List<Envio> listar() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Envio> buscar(@PathVariable Long id) {

        Envio envio = service.findById(id);

        if (envio != null) {
            return ResponseEntity.ok(envio);
        }

        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<?> guardar(@Valid @RequestBody EnvioRequest request) {

        Envio envio = new Envio();

        envio.setDestino(request.getDireccion());
        envio.setPeso(request.getPeso());
        envio.setTipo(request.getTipo());

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.save(envio));
    }

    @PatchMapping("/{id}/entregar")
    public ResponseEntity<Envio> entregar(@PathVariable Long id) {

        Envio envio = service.marcarEntregado(id);

        if (envio != null) {
            return ResponseEntity.ok(envio);
        }

        return ResponseEntity.notFound().build();
    }
}