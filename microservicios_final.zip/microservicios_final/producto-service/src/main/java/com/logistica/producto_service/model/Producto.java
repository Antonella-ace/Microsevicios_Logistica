package com.logistica.producto_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Entity
@Table(name = "productos")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Nombre obligatorio")
    @Column(nullable = false)
    private String nombre;

    @NotBlank(message = "Categoría obligatoria")
    private String categoria;

    @NotNull(message = "Precio obligatorio")
    @Min(value = 1, message = "Precio debe ser mayor a 0")
    private Double precio;

    @NotNull(message = "Stock obligatorio")
    @Min(value = 0, message = "Stock no puede ser negativo")
    private Integer stock;

    private String descripcion;

    private Boolean activo = true;
}