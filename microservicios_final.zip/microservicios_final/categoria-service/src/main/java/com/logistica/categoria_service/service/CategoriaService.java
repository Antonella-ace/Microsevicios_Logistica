package com.logistica.categoria_service.service;

import com.logistica.categoria_service.model.Categoria;
import com.logistica.categoria_service.repository.CategoriaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoriaService {

    private final CategoriaRepository repository;

    public CategoriaService(CategoriaRepository repository) {
        this.repository = repository;
    }

    public List<Categoria> listar() {
        return repository.findAll();
    }

    public Categoria guardar(Categoria categoria) {
        return repository.save(categoria);
    }

    public Categoria buscar(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Categoria no encontrada"));
    }

    public Categoria actualizar(Long id, Categoria categoria) {
        Categoria c = buscar(id);
        c.setNombre(categoria.getNombre());
        c.setDescripcion(categoria.getDescripcion());
        return repository.save(c);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}