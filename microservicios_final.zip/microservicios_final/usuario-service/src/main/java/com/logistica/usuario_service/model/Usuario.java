package com.logistica.usuario_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "usuarios")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Nombre obligatorio")
    private String nombre;

    @Email(message = "Correo inválido")
    @NotBlank(message = "Correo obligatorio")
    @Column(unique = true)
    private String correo;

    @NotBlank(message = "Password obligatoria")
    private String password;

    @NotBlank(message = "Rol obligatorio")
    private String rol;

    private Boolean activo = true;
}