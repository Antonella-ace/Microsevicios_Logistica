package com.logistica.usuario_service.service;

import com.logistica.usuario_service.model.Usuario;
import com.logistica.usuario_service.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

    private final UsuarioRepository repository;

    public UsuarioService(UsuarioRepository repository) {
        this.repository = repository;
    }

    public List<Usuario> listar() {
        return repository.findAll();
    }

    public Usuario guardar(Usuario usuario) {

        if (repository.findByCorreo(usuario.getCorreo()).isPresent()) {
            throw new RuntimeException("Correo ya registrado");
        }

        return repository.save(usuario);
    }

    public Usuario login(String correo){

        return repository.findByCorreo(correo)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
    }
}