package com.logistica.envio_service.repository;

import com.logistica.envio.model.Envio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface EnvioRepository extends JpaRepository<Envio, Long> {
    List<Envio> findByDestino(String destino);
    List<Envio> findByEstado(String estado);
    List<Envio> findByEntregadoTrue();
}



