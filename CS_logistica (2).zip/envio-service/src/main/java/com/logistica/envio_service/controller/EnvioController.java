package com.logistica.envio_service.controller;

import com.logistica.envio.model.Envio;
import com.logistica.envio.service.EnvioService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/envios")
@RequiredArgsConstructor
public class EnvioController {
    private final EnvioService service;

    @GetMapping
    public List<Envio> getAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Envio> getById(@PathVariable Long id) {
        Envio envio = service.findById(id);
        return envio != null ? ResponseEntity.ok(envio) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Envio> create(@RequestBody Envio envio) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.save(envio));
    }

    @PatchMapping("/{id}/entregar")
    public ResponseEntity<Envio> entregar(@PathVariable Long id) {
        Envio envio = service.marcarEntregado(id);
        return envio != null ? ResponseEntity.ok(envio) : ResponseEntity.notFound().build();
    }
}




