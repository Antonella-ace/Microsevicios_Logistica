package com.logistica.envio_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnvioDTO {

    // Campos que el CLIENTE puede enviar al crear un envío
    private String destino;
    private Integer peso;
    private String tipo;

    // Opcional: Campos que el CLIENTE puede recibir al consultar
    // (no pueden modificarlos, solo verlos)
    private Long id;
    private String estado;
    private Double costoEnvio;
    private String codigoSeguimiento;
}



