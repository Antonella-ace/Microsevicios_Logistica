package com.logistica.envio_service.service;


import com.logistica.envio.model.Envio;
import com.logistica.envio.repository.EnvioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class EnvioService {
    private final EnvioRepository repository;

    public List<Envio> findAll() {
        return repository.findAll();
    }

    public Envio findById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public Envio save(Envio envio) {
        envio.setFechaCreacion(LocalDateTime.now());
        envio.setCodigoSeguimiento(generarCodigo());
        envio.setCostoEnvio(calcularCosto(envio.getPeso(), envio.getDestino()));
        return repository.save(envio);
    }

    public Envio marcarEntregado(Long id) {
        Envio envio = findById(id);
        if (envio != null && !envio.getEntregado()) {
            envio.setEntregado(true);
            envio.setEstado("ENTREGADO");
            return repository.save(envio);
        }
        return null;
    }

    private String generarCodigo() {
        return "ENV-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    private Double calcularCosto(Integer peso, String destino) {
        double costoBase = 10.0;
        double costoPorKg = 2.5;
        return costoBase + (peso != null ? peso * costoPorKg : 0);
    }
}



